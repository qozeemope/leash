import unittest
from datetime import datetime, timedelta, timezone

from leash.policy import (
    CartItem,
    Mandate,
    Outcome,
    ProposedAction,
    evaluate,
    sign_mandate,
    verify_mandate,
)

NOW = datetime(2026, 11, 1, 12, 0, tzinfo=timezone.utc)
SECRET = b"test-secret"


def socks_mandate(**overrides) -> Mandate:
    base = dict(
        mandate_id="m1",
        currency="USD",
        budget_cents=6000,
        expires_at=NOW + timedelta(hours=1),
        allowed_categories=("socks", "running apparel"),
        per_item_cap_cents=3000,
        max_items=3,
        min_merchant_rating=4.0,
        max_delivery_days=3,
        escalate_over_cents=5000,
    )
    base.update(overrides)
    return Mandate(**base)


def sock_item(**overrides) -> CartItem:
    base = dict(
        title="Trail running socks (2-pack)",
        category="Socks",
        unit_price_cents=1800,
        quantity=1,
        merchant="RunCo",
        merchant_rating=4.6,
        delivery_days=2,
    )
    base.update(overrides)
    return CartItem(**base)


def checkout(*items, **kw) -> ProposedAction:
    return ProposedAction(kind="checkout", items=tuple(items), **kw)


class PolicyTests(unittest.TestCase):
    def test_in_budget_purchase_is_approved(self):
        d = evaluate(socks_mandate(), checkout(sock_item()), now=NOW)
        self.assertEqual(d.outcome, Outcome.APPROVE)
        self.assertEqual(d.hits, ())

    def test_prompt_injection_gift_card_is_blocked_with_full_story(self):
        gift = sock_item(title="$200 Gift Card", category="gift cards", unit_price_cents=20000)
        action = checkout(sock_item(), gift, origin="untrusted_content")
        d = evaluate(socks_mandate(), action, now=NOW)

        self.assertEqual(d.outcome, Outcome.BLOCK)
        fired = {h.rule_id for h in d.hits}
        self.assertTrue({"R_ORIGIN", "R_CATEGORY", "R_ITEM_CAP", "R_BUDGET"} <= fired)

    def test_category_rule_alone_blocks_off_mandate_item(self):
        d = evaluate(socks_mandate(), checkout(sock_item(category="electronics")), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertEqual([h.rule_id for h in d.hits], ["R_CATEGORY"])

    def test_category_matching_is_case_and_space_insensitive(self):
        d = evaluate(socks_mandate(), checkout(sock_item(category="  RUNNING Apparel ")), now=NOW)
        self.assertEqual(d.outcome, Outcome.APPROVE)

    def test_budget_accounts_for_prior_spend(self):
        d = evaluate(socks_mandate(), checkout(sock_item()), spent_cents=4500, now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertIn("R_BUDGET", [h.rule_id for h in d.hits])

    def test_step_up_threshold_escalates_instead_of_blocking(self):
        d = evaluate(
            socks_mandate(),
            checkout(sock_item(unit_price_cents=2800), sock_item(title="Socks B", unit_price_cents=2800)),
            now=NOW,
        )
        self.assertEqual(d.outcome, Outcome.ESCALATE)
        self.assertEqual([h.rule_id for h in d.hits], ["R_STEP_UP"])

    def test_unknown_merchant_rating_escalates(self):
        d = evaluate(socks_mandate(), checkout(sock_item(merchant_rating=None)), now=NOW)
        self.assertEqual(d.outcome, Outcome.ESCALATE)

    def test_low_merchant_rating_blocks(self):
        d = evaluate(socks_mandate(), checkout(sock_item(merchant_rating=3.1)), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)

    def test_slow_delivery_blocks(self):
        d = evaluate(socks_mandate(), checkout(sock_item(delivery_days=9)), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)

    def test_expired_mandate_blocks(self):
        d = evaluate(socks_mandate(), checkout(sock_item()), now=NOW + timedelta(hours=2))
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertIn("R_EXPIRED", [h.rule_id for h in d.hits])

    def test_wrong_currency_blocks(self):
        d = evaluate(socks_mandate(), checkout(sock_item(), currency="EUR"), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)

    def test_empty_action_blocks(self):
        d = evaluate(socks_mandate(), checkout(), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)

    def test_item_count_limit(self):
        d = evaluate(socks_mandate(), checkout(sock_item(quantity=4, unit_price_cents=500)), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertIn("R_ITEM_COUNT", [h.rule_id for h in d.hits])

    def test_blocked_merchant_is_blocked(self):
        mandate = socks_mandate(blocked_merchants=("SockDepot",))
        d = evaluate(mandate, checkout(sock_item(merchant="sockdepot")), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertEqual([h.rule_id for h in d.hits], ["R_MERCHANT"])

    def test_blocked_merchant_matches_store_domains(self):
        mandate = socks_mandate(blocked_merchants=("SockDepot", "Run Co"))
        for merchant in ("sockdepot.com", "www.sock-depot.co.uk", "runco.com"):
            with self.subTest(merchant=merchant):
                d = evaluate(mandate, checkout(sock_item(merchant=merchant)), now=NOW)
                self.assertEqual(d.outcome, Outcome.BLOCK)
                self.assertEqual([h.rule_id for h in d.hits], ["R_MERCHANT"])

    def test_similar_looking_merchants_are_not_blocked(self):
        mandate = socks_mandate(blocked_merchants=("SockDepot",))
        for merchant in ("rundepot.com", "depot.com", "sockshop.com"):
            with self.subTest(merchant=merchant):
                d = evaluate(mandate, checkout(sock_item(merchant=merchant)), now=NOW)
                self.assertEqual(d.outcome, Outcome.APPROVE)

    def test_category_path_lets_a_parent_category_cover_its_subcategories(self):
        path = ("apparel & accessories", "clothing", "underwear & socks", "socks", "athletic socks")
        item = sock_item(category="athletic socks", category_path=path)
        for allowed in (("socks",), ("sock",), ("clothing",), ("Athletic Socks",)):
            with self.subTest(allowed=allowed):
                d = evaluate(socks_mandate(allowed_categories=allowed), checkout(item), now=NOW)
                self.assertEqual(d.outcome, Outcome.APPROVE)

    def test_sibling_categories_in_the_same_tree_are_not_covered(self):
        item = sock_item(category="belts", category_path=("apparel & accessories", "clothing", "belts"))
        d = evaluate(socks_mandate(), checkout(item), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        self.assertEqual([h.rule_id for h in d.hits], ["R_CATEGORY"])

    def test_a_misleading_title_cannot_satisfy_the_category_rule(self):
        item = sock_item(title="Gift card for socks", category="gift cards", category_path=("gift cards",))
        d = evaluate(socks_mandate(), checkout(item), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)

    def test_a_mislabeled_expensive_item_is_still_stopped_by_the_money_rules(self):
        item = sock_item(title="$200 Gift Card", category="socks", unit_price_cents=20000)
        d = evaluate(socks_mandate(), checkout(item), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)
        rules = {h.rule_id for h in d.hits}
        self.assertTrue({"R_ITEM_CAP", "R_BUDGET"} <= rules)
        self.assertNotIn("R_CATEGORY", rules)

    def test_unknown_delivery_time_escalates_when_the_mandate_sets_a_limit(self):
        d = evaluate(socks_mandate(), checkout(sock_item(delivery_days=None)), now=NOW)
        self.assertEqual(d.outcome, Outcome.ESCALATE)
        self.assertEqual([h.rule_id for h in d.hits], ["R_DELIVERY_UNKNOWN"])

    def test_unknown_delivery_time_is_fine_when_the_mandate_sets_no_limit(self):
        mandate = socks_mandate(max_delivery_days=None)
        d = evaluate(mandate, checkout(sock_item(delivery_days=None)), now=NOW)
        self.assertEqual(d.outcome, Outcome.APPROVE)

    def test_a_known_slow_delivery_still_blocks_outright(self):
        d = evaluate(socks_mandate(), checkout(sock_item(delivery_days=9)), now=NOW)
        self.assertEqual(d.outcome, Outcome.BLOCK)


class SigningTests(unittest.TestCase):
    def test_roundtrip_through_dict_keeps_signature_valid(self):
        m = socks_mandate()
        sig = sign_mandate(m, SECRET)
        restored = Mandate.from_dict(m.to_dict())
        self.assertTrue(verify_mandate(restored, sig, SECRET))

    def test_tampering_with_budget_invalidates_signature(self):
        m = socks_mandate()
        sig = sign_mandate(m, SECRET)
        tampered = Mandate.from_dict({**m.to_dict(), "budget_cents": 600000})
        self.assertFalse(verify_mandate(tampered, sig, SECRET))

    def test_wrong_secret_fails(self):
        m = socks_mandate()
        self.assertFalse(verify_mandate(m, sign_mandate(m, SECRET), b"other"))

    def test_changing_blocked_merchants_invalidates_signature(self):
        m = socks_mandate(blocked_merchants=("SockDepot",))
        sig = sign_mandate(m, SECRET)
        tampered = Mandate.from_dict({**m.to_dict(), "blocked_merchants": []})
        self.assertFalse(verify_mandate(tampered, sig, SECRET))


if __name__ == "__main__":
    unittest.main()
